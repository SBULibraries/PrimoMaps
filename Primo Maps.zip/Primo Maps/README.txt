Authors:
Matthew Hartman (Stony Brook University)
Timothy Kohn (Stony Brook University)
Foundational Codebase Authors:
Will Martin (University of North Dakota)
Rebecca Brown (University of North Dakota)


This __ INSERT TITLE HERE __ codebase was created by Matthew Hartman (Head of Resource Sharing) 
and Timothy Kohn (Resource Sharing Coordinator) of Stony Brook University. The foundational
code was written by Will Martin and Rebecca Brown of the University of North Dakota, but has been
significantly adapted for use by Stony Brook University. ChatGPT and other LLMs were used to improve code. 

Major adaptations include:
-A python based system for layering a locator on a base stack map.
-A subarray methodology for passing information to the html page.
-Switchers for use with multiple ALMA libraries.
-Functionality for handling oversize items and other materials that aren't 'in order' so to speak.
-A redesigned front end with css and javascript. 

Any questions about this code can be sent to ill@stonybrook.edu

HOW TO GET STARTED:
1- 